Zaal Belihomji (zbeliho7)
Kenneth Swindell (kswindel)

Our application asks a user to enter their favorite Jordan sneaker 
with their corresponding shoe size which ou can add a Jordan shoe to your wish list
or you can delete a shoe from your wishlist. At our main page, we have a dad joke 
generate which spices our page up for some fun dad jokes!

https://icanhazdadjoke.com/api is the link to our dad joke api